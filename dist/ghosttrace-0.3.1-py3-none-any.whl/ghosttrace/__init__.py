"""GhostTrace — Record the roads your AI agent didn't take."""
__version__ = "0.3.1"
